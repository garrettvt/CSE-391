#!/bin/bash

####################################
# Name: <Your name here>
# CSE 391 - Winter 2020 
# Homework 8 - Task 1
####################################

function problem1 {
  # Type your answer to problem #1 below this line
  echo "not yet implemented"
}

function problem2 {
  # Type your answer to problem #2 below this line
  echo "not yet implemented"
}

function problem3 {
  # Type your answer to problem #3 below this line
  echo "not yet implemented"
}

function problem4a {
  # Type your answer to problem #4a below this line
  echo "not yet implemented"
}

function problem4b {
  # Type your answer to problem #4b below this line
  echo "not yet implemented"
}

function problem5 {
  # Type your answer to problem #5 below this line
  echo "not yet implemented"
}

function problem6 {
  # Type your answer to problem #6 below this line
  echo "not yet implemented"
}

function problem7 {
  # Type your answer to problem #7 below this line
  echo "not yet implemented"
}

