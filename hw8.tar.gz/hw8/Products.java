import java.io.*;

/* Check out these products! */

public class Products { /* a good class, but not as good as cse 391 */

    public Product faangTitle() {
        return new Product("Title", "FAANG title design", "faangpic.png", 5.0);
    }

    public Product applepencil() {
        return new Product("Apple Pencil", "Stylus for iPad Pro", "applepencil.jpg",99.0);
    }

    public Product airpods() {
        return new Product("Airpods", "Quality earbuds for sleep, run, casual, etc", "airpods.jpg", 130);
    }

    public Product genesis_g70() {
        return new Product("Genesis G70", "A fast and luxury car", "genesis-g70.jpg", 1.0);
    }

    public Product kobeBeef() {
        return new Product("Kobe Beef", "Beef from Kobe Prefecture", "kobe.jpg", 489);
    }

    public Product pocky() {
        return new Product("Pocky", "Tasty Snack", "pocky.jpg", 1.0);
    }

    public Product shampooBrush(){
        return new Product("Shampoo Brush", "Perfect for massaging the scalp, spreading shampoo, and detangling!", "shampoo_brush.jpg", 10);
    }

    public Product gb() {
        return new Product("Game Boy", "This is a gameboy console", "gb.jpg", 20.0);
    }

    public Product japanCoal() {
        return new Product("Japan Coal", "This is a rare package of high quality Japan Coal for incense burner, from Japan. It menaces with spikes of Japan Coal. All craftsmanship is of the highest quality.", "japan_coal.jpg", 16.99);
    }

    public Product swift() {
        return new Product("Swift", "A good programming language", "swift.png", -1.0);
    }

    public Product goldenRetriever() {
        return new Product("Golden Retriever", "The best dog", "goldenretriever.jpg", 10000);
    }

    public Product dogecoin() {
        return new Product("Dogecoin", "wow such cryptocurrency very relevant meme", "dogecoin.png", 1280000.0);
    }

    public Product eggTart() {
        return new Product("Egg Tart", "This egg tart is the BEST!", "eggTart.jpg", 5.0);
    }

    public Product hammer() {
        return new Product("Hammer", "You can use it to hammer things!", "hammer.jpg", 2.7);
    }

    public Product bugcat() {
        return new Product("Bugcat", "This bugcat doesn't want to work!", "nowork.jpg", 0.0);
    }

    public Product fennekin() {
        return new Product("Fennekin Plush", "A cute Pokemon plush", "fennekin.jpg", 100);
    }

    public Product fact_checker() {
        return new Product("Fact Checker Brain Implant", "A brain implant that will stop you from saying things you shouldn't have said, eg. during the presidential debate", "fact_checker.jpeg", 1000000.00);
    }

    public Product kekw() {
        return new Product("kekw", "an excellent meme and emote used on Twitch.tv", "kekw.jpg", 111223.123);
    }

    public Product brians_corn() {
        return new Product("Corn on the cob", "The best corn you will ever eat my friend", "Boiled-Corn-on-the-Cob.jpg", 100);
    }

    public Product tontonWinnie() {
        return new Product("Tonton Winnie", "A timid bear", "tonton_winnie.png", 99999990);
    }

    public Product eggie() {
        return new Product("Really Cute Egg", "a cute egg with a smile", "cute-egg.png", 78.0);
    }

    public Product Doggo() {
        return new Product("Cheap Doggo", "A super cute doggo", "dog.jpg", 0.01);
    }

    public Product FountainPen() {
        return new Product("Abalone Fountain Pen", "A fine writing instrument inlaid with abalone shell", "endura_abalone.jpg", 135.00);
    }

    public Product diya() {
        return new Product("Diya", "A lamp lit on Diwali", "diya.jpg", 4.0);
    }

    public Product covidFreeAir() {
        return new Product("A Bag of COVID-free Air", "The only guarantee of 2020!", "covid_free_bag_of_air.jpg", 5200.0);
    }

    public Product Kitty() {
        return new Product("Meow Meow", "A super cute ragdoll Kitty.", "super_cute_kitty.jpg", 9999999.99);
    }

    public Product mints() {
        return new Product("A pack of mints!", "Organic Mints", "mints.jpg", 1.99);
    }

    public Product Borat() {
        return new Product("Borat!", "Azamat's homie.", "borat.jpg", 10.01);

    }

    public Product jemGuitar() {
        return new Product("Jem Guitar", "A really really cool guitar", "JEMguitar.jpg", 1000.0);
    }

    public Product keyboard() {
        return new Product("keyboard","the coolest keyboard in the world","keyboard.jpg", 500.0);
    }

    public Product detlef() {
        return new Product("FAANG", "FAANG", "Detlef.jpg", 1000.0);
    }

    public Product faang() {
        return new Product("Philip's pretty cool product", "Not sure what id does", "faang.jpg", 5.0);
    }

    public Product juicy() {
        return new Product("Juice", "Yummy yummy juicy", "juice.png", 11.0);
    }

    public Product indomie() {
        return new Product("Indomie", "The best instant noodles to ever exist (MSG is good for you)", "indomie.jpg", 0.99);
    }

    public Product theOfficeMug() {
        return new Product(" The Office Mug", "Michael Scotts Lengendary Worlds Best Boss Coffee Mug", "theofficemug.png",
                5.99);
    }

    public Product myProduct() {
        return new Product("Hunter's Not so Awesome Product", "It's actually just dirt", "dirt.jpeg", 0.0);
    }

    public Product belly() {
        return new Product("A Belly Picture", "A drawing for you Sptofiy playlist of the same name", "belly.jpg", 0.0);
    }

    public Product HiTech() {
        return new Product("HiTech Computer", "latest computer on the market", "HiTech.jpg", 9.0);
    }


    public Product GraphGear() {
        return new Product("Chris' Cool Product!", "The best mechanical pencil on the market", "GraphGear1000.jpg", 11.85);
    }

    public Product fire() {
        return new Product("Fire", "It's actually just fire. The package comes on fire. Run.", "fire.jpg", 6.66);
    }

    public Product frog() {
        return new Product("Frog", "He's quite polite.", "frog.jpg", 4.00);
    }

    public Product bowlingPins() {
        return new Product("Just some bowling pins", "There's a metal bowling ball too", "Bowling_Pins.png", 1.02);
    }

    public Product hagrid() {
        return new Product("Hagrid", "the one and only", "hagrid.jpg", 10.0);
    }

    public Product chai() {
        return new Product("Chai", "Bubbly (not boba) milky spicy cup of milk-tea", "chai.jpg", 5.0);
    }

    public Product blender() {
        return new Product("Blender", "The perfect appliance for making smoothies", "blender.jpg", 10.0);
    }

    public Product candle() {
        return new Product("Candle", "The best candle for a chill Friday night", "candle.jpg", 5.5);
    }

    public Product money() {
        //Jeremy Lin's product
        return new Product("MONEY", "Buy less for more at the 5 Dollar Store!", "money.jpg", 9.99);
    }

    public Product ballot(){
        return new Product("The most ever crucial ballot", "It might determine the future of America!", "product.png", 2147483648.0);
    }

    public Product gloves() {
        return new Product("This is a pair of gloves", "Don't hit random people", "gloves.jpg", 10.0);
    }


    public Product egg2() {
        return new Product("A very nice egg", "Its very nice, trust me", "egg.jpg", 4.0);
    }

    public Product seaShell() {
        return new Product("Matthew's sea shells by the sea shore", "sea shells", "shell.jpg", 10.0);
    }

    public Product theBurritoTrough() {
        //Cole Purcell's Product
        return new Product("The Burrito Trough", "Never again will you have to worry about making a mess while eating a burrito, plus it's hands-free, leaving you able to go about your day with a tasty meal at the ready!", "BurritoTrough.jpg", 12.69);
    }

    public Product formulaOneCar(){
        return new Product("Mercedes W11 Formula 1 car",  "The best track-day machine built to date",  "mercedes_W11.jpg", 20000000.0);
    }

    public Product bowtie() {
        return new Product("Bowtie", "An immaculate bowtie", "bowtie.jpg", 1.1);
    }

    public Product pawButton() {
        return new Product("Paw button", "Summons Dubs to come do your CSE homework!", "paw.jpeg", 1.1);
    }

    public Product turkey() {
        return new Product("Live Turkey", "Get your new pet turkey!", "turkey.jpeg", 0.0);
    }

    public Product happyDog() { // Steve Pater's product
        return new Product("HappyDog Dog Treats!", "Clearly this dog is happy!", "HappyDog Dog Treats.jpeg", 10.0);
    }


    public Product roseWater() {
        return new Product("Rose Water", "all natural and refreshing", "project.jpeg",9.99);
    }

    // Saagar Mehta's product
    public Product chocolateCake() {
        return new Product("Chocolate cake", "the best emotional support on the market", "chocolate_cake.jpg", 11.7);
    }

    public Product poke() {
        return new Product("Poke", "The best poke bowl you've ever seen... and that you'll ever taste!", "poke.jpeg", 22.1);
    }

    public Product bit() {
        return new Product("Bit", "Instructions on how to accomplish bit masking", "bit.png", 10.0);
    }

    public Product carlWheezer() {
        return new Product("Carl Wheezer", "The oscar-winning actor from the hit Jimmy Neutron series", "Carl.png", 59.0);
    }

    public Product petRock() {
        // Ryan Li's product
        return new Product("Pet Rock", "This is some random rock that you can keep as a pet", "Pet_rock.jpg", 999.0);
    }

    // Patrick Ho's product
    public Product boba() {
        return new Product("Boba", "Fresh boba from YiFang Taiwan Fruit Tea on the Ave!", "boba.png", 5.0);
    }

    public Product get_me_gundam() {
        return new Product("Gundam RX-78-2", "Get this if you want to fight Zeon", "Gundam.jpg", 782.0);
    }

    public Product safSender(){
        // Sierra Lee's product
        String desc = "Records sound and automatically sends recording to pre-designated contact for safety and to aid in rescue in kidnappings and assaults.";
        return new Product("Safety Sender", desc, "voice_recorder.jpg", 10.0);
    }

    public Product hhkb() {
        // Yingfan Chen's product
        return new Product("Happy Hacking Keyboard", "Vimers' keyboard", "hhkb.jpg", 299.0);
    }

    public Product sunglasses() {
        return new Product("Sunglasses", "These will protect your eyes, and your identity if you pair with a mask","sunglasses.jpg", 10.0);

    }

    public Product bike_light() {
        return new Product("Bike Light", "Keeps you safe when riding your bike in the dark", "bikelite.jpg", 25.0);
    }

    public Product red_panda() {
        // Iulia Eseanu's product
        return new Product("Red Panda", "Look at this if you want to be happy", "red_panda.jpg", 6.0);
    }

    public Product candy_bar() {
        //Soren Dahl's product
        return new Product("100 Grand", "A delicious candy bar!", "100grand.png", 0.5);
    }

    public Product strawberry() {
        //Giselle Gunawan's product
        return new Product("Strawberry fruit", "Sweet and sour fruit", "Strawberry_BNC.jpg", 3.0);
    }

    public Product getChocoShrooms() {
        //Michael Li's Product
        return new Product("Chocolate Mushrooms", "Just some chocolate mushrooms", "chocoshrooms.jpeg", 10.0);
    }

    public Product abdithebanana(){
        //Sulaiman's Products
        return new Product ("banana", "So sweet and palatable", "abdithebanana.png", 10.00);
    }

    public Product getBubbleTea() {
        // Jacob McKenney's Product
        return new Product("Bubble Tea with Tapioca", "Delicious annd filled with texture: a great refreshment", "bubble-tea.jpg", 6.0);
    }

    public Product mikuCrying() {
        // Tony Song's product
        return new Product("Fuwa Fuwa Miku", "Oh, no! It is crying!", "cry.jpg", 30.0);
    }

    public Product microphone() {
        return new Product("Microphone", "High Quality Microphone for Karaoke Nights", "Microphone.jpg", 50.0);
    }

    public Product bible() {
        //Nardin's Product
        return new Product("Bible", "A chapter a day keeps the devil away","bible.jpg", 100.0);
    }

    public Product babyDoll() {
        // Rinav's Product
        return new Product("Baby Doll", "Baby Doll when you need extra nightmare fuel", "doll.jpg", 30.0);
    }

    public Product getSlider() {
        //Devesh's Product
        return new Product("Slider", "A Slider that you can use to asthestic purposes", "horizontal_line_slider.jpg", 5.0);
    }

    public Product clownWig() {
        //maggie's product
        return new Product("Clown Wig", "Life's a circus and we're all clowns", "clown.jpg", 10.0);
    }

    public Product bleach() {
        //Christian's product
        return new Product("Bleach", "For your weekly cleansing", "bleach.jpg", 12.0);
    }

    public Product rock() {
        // Evan's Product
        return new Product("Rock", "It's a rock", "rock.jpg", 1.0);
    }

    public Product yoyo() {
        //Assaf's Product
        return new Product("Yoyo", "A yoyo", "yoyo.jpeg", 2.0);
    }

    //Mike's product
    public Product glasses() {
        return new Product("Glasses","Blue light protective glasses","glasses.jpg",24.99);
    }

    public Product littleidea(){
        //Chang Liu's Product
        return new Product("Little Idea", "The little idea when you think about a good one", "littleidea.jpg", 8.0);
    }

    public Product mclaren() {
        // Benjamin's Product
        return new Product("McLaren Senna GTR", "It's more than just a race car", "mclaren.jpg", 10.0);
    }

    public Product lipstick(){
        //Camila's Product
        return new Product("Lipstick", "A red lipstick", "lipstick.png", 8.0);
    }

    public Product dice(){
        //Jiamae's Product
        return new Product("Dice", "A six sided die", "random-dice.jpg", 5.99);
    }

    public Product giraffe() {
        return new Product("A big giraffe", "Giraffe on a roof", "20190803-_DSC7920.jpg", 1024.0);
    }

    public Product cheesecake() {
        // Alicia's Product
        return new Product("Cheesecake", "Best kind of cheese, best kind of cake", "cheesecake.jpg", 27.18);
    }

    public Product CSCoffeeMug() {
        return new Product("CS coffee mug", "A nerdy mug for your coffee", "cs-coffee-mug.jpg", 10.99);
    }

    public Product FutureRobot() {
        //Jinghao's future AI product
        return new Product("A Home Use Robot", "The most intelligent robot ever", "futureAI.jpg", 999.99);
    }


    public Product cuteDoll() {
        // Tiphanie's product
        return new Product("A random cute doll", "It's just a doll", "doll.png", 999999.0);
    }

    public Product bunnyRabbit() {
        // Melissa Mitchell's Product
        return new Product("Adorable pet", "A cute baby bunny", "bunny-rabbit.jpg", 25.00);
    }

    public Product waterbottles() {
        //Yae's product
        return new Product("Water you waiting for?", "lost and found water bottles", "waterbottles.jpg", 1.0);
    }

    public Product AmongUsPlushies() {
        //Kayla Hoang's Product
        return new Product("Among Us Plushies", "Our favorite adorable impostors", "amongus_plushies.jpg", 19.99);
    }

    public Product LiteralMoney() {
        //Jacob Christy's Product
        return new Product("Literal Money", "Who said it couldn't solve all problems", "JustMoney.jpg", 20.01);
    }

    public Product funky_kong() {
        // John Rice's Product
        return new Product("funky_kong", "Best driver in Mario Kart Wii", "funky_kong.png", 30000000.00);
    }

    public Product buyGold() {
        // Nithin Tamilselvan's Product
        return new Product("It's gold", "Always appreciating in value", "goldImage.jpg", 36.8);
    }

    public Product stapler() {
        // Ben Zhang's Product
        return new Product("THE Stapler", "What more is there to say?", "stapler.jpg", 3.91);
    }

    public Product album() {
        // Yetao's Product
        return new Product("album", "The Doors, 1967", "album.jpg", 19.99);
    }

    public Product glass() {
        return new Product("glasses", "Gives light to a dark world", "glasses.jpg", 100.0);
    }

    public Product lamp() {
        return new Product("lamp", "It's a green lamp", "lamp.jpg", 25.0);
    }

    public Product milkteamint() {
        return new Product("Mint Milk Tea", "it's just milk tea", "milkteamint.jpg", 21.0);
    }

    public Product racecar() {
        //Kevin Wang's Product
        return new Product("Race Car Bed", "Race Car Bed for adults who still embrace the child within", "racecar.jpg", 55.0);
    }

    public Product football() {
        //Zedong Wu's Product
        return new Product("football", "This is an official size football played in the NFL", "football.jpg", 100.0);
    }

    public Product mask() {
        // Qingyuan's Product
        return new Product("mask", "Trust me, you really need it", "mask.jpg", 3.14);
    }

    public Product drone() {
        //Justin Yang's Product
        return new Product("drone", "This is a trusty drone", "drone_img.jpg", 100.0);
    }

    public Product waterpoptart() {
        //Bella Rivera's Product
        return new Product("Water Flavored Pop Tarts", "the pastry that keeps you hydrated", "waterpoptart.jpg", 3.68);
    }

    public Product iPhone() {
        return new Product("The new iPhone ~ ", "Like usual really expensive", "iPhone 12.jpg", 849.0);
    }

    public Product ThaiFood(){
        return new Product("Pad Thai", "Really flavorful noodles", "padThai.jpg", 11.95);
    }

    public Product bunny() {
        //Annie Denton's product
        return new Product("Bunny", "Baby flop eared rabbit for sale", "bunny.jpg", 10.0);
    }

    public Product orange() {
        // Vania Widjaya's product
        return new Product("Orange", "Just a tasty and orange-colored orange", "orange.png", 1.0);
    }

    public Product cheezits(){
        return new Product("Cheez-it Box", "Because isn't everybody addicted to cheezits? Let's be real.", "cheezit_box.PNG", 2.99);
    }

    public Product krabbyPatty() {
        return new Product("Krabby Patty", "A meatless burger of sorts made from seaweed-sea buns, undersea vegetables, condiments, and a patty; it can also be ordered with cheese.", "krabby-patty.jpg", 0.99);
    }

    public Product mandalorian(){
        //Zage's Product
        return new Product("mandalorian inspiration", "This photo should inspire you to watch the mandalorian because it is adorable.", "mando.jpg",3.99);
    }

    public Product iPhone20() {
        return new Product("iPhone20", "Cameras, screen, battery, headphones, charger, processors, functionality sold separately.", "iPhone20.jpg", 9999999.99);
    }

    public Product bobaKeychain() {
        return new Product("Boba Keychain", "For lovers of boba and cute things alike!", "boba_keychain.png", 10.98);
    }

    public Product candyColors() {
        return new Product("Colorful candies", "For kids who missed trick-or-cheating.", "Candies.jpg", 0.99);
    }

    public Product succulent() {
        return new Product("Succulent", "A small green plant that goes great indoors", "succulent.jpg", 4.99);
    }

    public Product baguette() {
        return new Product("Baguette", "C'est comme si vous étions dans une petite boulangerie à Paris, moins le tourisme!", "baguette.jpg", 8.75);
    }

    public Product babyYoda() {
        return new Product("Baby Yoda", "A loveable addition to any household", "baby-yoda.jpg", 14.99);
    }

    public Product house() {
        return new Product("House", "A comfort place to live", "house.jpg", 1000000);
    }

    public Product bubbleGum() {
        return new Product("Bubble Gum", "Chewy, Dewey, and Louie!", "bubble_gum.jpg", 0.99);
    }

    public Product jfk() {
        return new Product("Former President John F. Kennedy", "It's literally the former U.S. president John F. Kennedy. Like, it's literally him.", "JFK.png", 17.38);
    }

    public Product cockpit(){
        return new Product("Cockpit", "When Chickens Fly", "cockpit.jpg", 2.00);
    }

    public Product ketchup(){
        return new Product("Ketchup", "The classic heinz formula", "ketchup.jpg", 5.99);
    }

    public Product car(){
        //Alex Wang's product
        return new Product("Car", "Next gen automobile", "car.png", 10.0);
    }

    public Product blivet(){
        // Aiden's Product
        return new Product("Blivet", "Exactly what it looks like. Don't ask how I managed to make an impossible object possible--trying to remember makes my brain fuzzy.", "Blivet.png", 13.01);
    }

    public Product obamium() {
        return new Product("Obamium", "Finally, Obamium.", "obamium.jpg", 17.76);
    }

    public Product usedB747forSale() {
        //Product introduced by David Roy
        return new Product("Used B747: Like new!", "Great for commercial and private use. Life vests not included. Purchases comes with 100 gallons of jet fuel", "B747.jpg", 2000000000000.99);
    }

    public Product monkeyBrainProp(){
        return new Product("Indiana Jones Monkey Brain", "Own a piece of cinematic history with the Monkey Brain prop from Indiana Jones and the Temple of Doom!", "IJ_monkey_brain_prop.png", 14000.00);

    }

    public Product getDeliciousCoffee() {
        return new Product("Coffee", "What EVERYONE needs to get through the day.", "cups-of-coffee.jpg", 1.99);
    }

    public Product AmazingGamingChair(){
        return new Product("Gaming Chair", "Just a gooooood olllll' gaming chair.","chair_product.jpg",420.69);
    }

    public Product Album() {
        return new Product("Hins Great Album", "Something that can smooth your soul if you understand Cantonese.", "Hins Great Album.jpg", 49.99);
    }

    public Product vgg16Network() {
        return new Product("a convolutional neural network", "makes me wanna hit my head against the wall but is really effective for classifying image", "vgg16.jpeg", 1234.0);
    }

    public Product pylon() {
        return new Product("Protoss Pylon", "Provides power to nearby Protoss structures.", "pylon.jpg", 100.0);
    }

    public Product getGoldfish() {
        return new Product("Goldfish", "The snack that smiles back", "Goldfish.jpg", 1.0);
    }

    //Varun's Product
    public Product calculator() {
        return new Product("Calculator", "A friendly reminder to appreciate the calculator", "calculator.jpeg", 99.99);
    }

    // Nakia's Product
    public Product cactus() {
        return new Product("Realistic Cactus", "If you don't have a green thumb thid is the plastic plant made just for you!", "cactus.jpg", 7.99);
    }

    // Allison's Product
    public Product donuts() {
        return new Product("Donuts", "Eat more hole foods!", "donuts.jpg", 10.99);
    }

    public Product halo() {
        return new Product("Halo 3", "The third installment in the Halo franchise.", "halo.jpg", 9.99);
    }

    public Product shirtBoundless() {
        return new Product("Boundless Shirt", "Go Huskies! This shirt is special because it comes with wrinkles.", "shirt_boundless.jpg", 1.99);
    }

    public Product jelly(){
        return new Product("Jelly", "An incredibly taesty treat perfect for cult meetings, linear algebra, silencing dissenters, etc.", "Jelly.png", 9064.69);
    }

    public Product gamerHeadphones(){
        return new Product("Certified Gamer Headphones", "Hear everything you want to hear, while ignoring all your responsibilities", "perfectIdea.jpg", 63.59);
    }

    public Product gumDispenser(){
        return new Product("Gum Dispenser", "Give people a single piece of gum at a time so they don't touch your stuff", "gum-dispenser.jpeg", 5.99);
    }

    public Product dog() {
        return new Product("A dog", "A wonderful pet for your very own", "dog.jpg", 18.99);
    }

    public Product goodOno() {
        return new Product("Good Ono", "Fried dough balls", "panikeke.jpg", 0.50);
    }

    public Product soySauceCandy() {
        return new Product("Soy Sauce Candy", "Soy saucy and sweet. An umami explosion. It's soy sauce candy.", "soysaucecandy.jpg", 5.75);
    }

    public Product wallet() {
        return new Product("Wallet", "It's a wallet.", "wallet.JPG", 10.0);
    }

    //Jun's Product
    public Product ramen() {
        return new Product("ISHIDA Ramen", "It's delicious and yummy", "RAMEN.jpg", 12.99);
    }

    public Product chickenlittle() {
        return new Product("Chicken Little", "Fun for the whole family!", "chickenlittle.jpg", 30.00);
    }

    public Product racket() {
        return new Product("Tennis Racket", "Roger Federer's old racket", "tennis_racket.jpg", 20.0);
    }

    public Product knitMonster() {
        return new Product("Knit Monster", "A monster friend to cuddle", "knit-monster.jpg", 19.99);
    }

    public Product swimmingGoggles() {
        return new Product("Form Goggles", "Smart goggles that track your performance underwater!", "form_goggles.jpg",  				199.00);
    }

    public Product poGgers() {
        return new Product("Man pogging", "a man with his lips in pog position", "pog.jpg", 69.99);
    }

    public Product pikachuPlush() {
        return new Product("Pikachu Plush", "A soft, cuddly pikachu plush.", "pikachu.jpg", 100.00);
    }

    public Product toyTank(){
        return new Product("Toy Tank", "A SUPER COOL TANK", "tank.png", 0.99);
    }

    public Product vietnameseFood() {
        return new Product("Vietnamese food", "Some good'ol home cooked Vietnamese food", "vietnameseFood.jpg", 0.99);
    }


    public Product googleMeme(){
        return new Product("A meme from Reddit", "a funny meme", "googleMeme.jpg", 15.00);
    }

    public Product seal(){
        return new Product("Seal", "Seal the Deal", "download-1.jpg", 100.00);     }

    public Product cerveloS5() {
        return new Product("Cervelo S5", "Fast bike", "cervelo.jpg", 500.00);
    }

    public Product wafflemaker() {
        return new Product("wafflemaker", "Makes a waffle!", "wafflemaker.jpeg",                           200.01);
    }

    public Product d20() {
        return new Product("d20", "Let the rng gods decide your fate now", "d20.jpg", 2.99);
    }

    public Product oilRig() {
        return new Product("Oil Rig", "Full industrial offshore oil rig which harvests oil for money", "Rust Oil Rig.jpg", 3.50);
    }

    public Product plane() {
        return new Product("plane", "Your own personal airplane", "plane.jpg", 5000000.00);
    }

    public Product blueHorn(){
        return new Product("Blue French Horn", "A nice gift for your mother and not your aunt.","blue-french-horn.jpg", 10.00 );
    }

    public Product redSoloCup() {
        return new Product("Red Solo Cup", "A cup", "red_solo_cup.jpg", 0.5);
    }

    public Product aadiRobot() {
        return new Product("Aadi Robot", "Arduino robot", "aadi_robot.jpg",1);
    }

    public Product Oreo() {
        return new Product("Oreo", " dellicous oreo", "oreo.jpg", 100000);
    }

    public Product egg() {
        return new Product("Gudetama Wallpaper", "A picture of a lazy egg", "Gudetama_Wallpaper.png", 2.00);
    }

    public Product LotsOfYogurt() {
        return new Product("A lot of yogurt", "Lots of yogurt", "SiggiYogurt.png", 30.43);
    }

    public Product Apple() {
        return new Product("Apple","logo","Apple.png",500000000.00);
    }

    public Product Pikachuu() {
        return new Product("Pikachu", "best pkm eva", "pikachu.png", 99999.99);
    }

    public Product AirPodsPro(){
        return new Product("AirPods Pro", "listen music", "product_image.jpeg", 250);
    }

    public Product horridNecktie() {
        // if this breaks anything Jason Langley was responsible
        return new Product("Horrid Necktie","A necktie with a garish pattern. It is nightmarishly vivid. (FAANG does not legally guarantee any supernatural manifestations as a result of purchasing the Horrid Necktie.)","Neck_tie.png",6.66);
    }

    public Product doggyBackpack() {
        return new Product("Doggy Backpack", "Cutest lil backpack for a doggy U ever saw", "dapper_doggies.jpg", 28.95);
    }

    public Product wonder_bread() {
        return new Product("Wonder Bread", "The best thing since...", "wonder_bread.jpg", 0.59);
    }

    public Product cat_burrito() {
        return new Product("Cat Burrito", "Keeping your cat dry since 1810", "purrito6.jpg", 0.0000001);
    }

    public Product bestIphone() {
        //Roman's method
        return new Product("Best Iphone", "The best phone on market", "bestIphone.jpg", 1299.00);
    }

    public Product Sephiroth() {
        return new Product("Sephiroth", "FF7", "Sephiroth.jpg", 1.84);
    }

    public Product Radio() {
        return new Product("Vintage radio", "A highly valued vintage radio", "radio.jpeg", 199.99 );
    }

    public Product betaWooper() {
        return new Product("Beta Wooper", "mega meme dog", "bw.jpeg", 2.2);
    }

    public Product cat() {
        return new Product("cat", "adopt a cute cat today!", "cat.jpg", 20);

    }

    public Product popcorn() {
        return new Product("Popcorn", "popped corn", "popcorn.jpg", 28.99);
    }
}

