import java.io.*;

public class Staff {

    public Employee hunter() {
        return new Employee("Hunter", "CEO", "A very nice and relatable boss", "hunter.jpg");
    }

    // Add your methods below here!
    public Employee andyZ() {
        return new Employee("Andy Zheng", "Lively AI Team Leader", "Still want to sleep", "Andy_Zheng.JPG");
    }

    public Employee ag() {
        return new Employee("Aviral Gupta", "Sleepy", "I want to sleep", "ag.jpg");
    }

    public Employee oz() {
        return new Employee("Osbert Lee", "unbelievably tired", "I want sleep", "osbert.jpg");
    }

    public Employee va() {
        return new Employee("Va", "gardener", "tired", "tired.jpg");
    }

    public Employee az() {
        return new Employee("Apollo Zhu", "Director Cat", "Simply cat", "az.png");
    }

    public Employee jp() {
        return new Employee("Jae Park", "Genius", "?", "jp.png");
    }

    public Employee hlai() {
        return new Employee("Yvonne", "CFO", "Nice, nice and nice", "lai.jpg");
    }

    public Employee wandak() {
        return new Employee("Wanda", "ded :(", "Overworked and underpaid...", "ded.png");
    }

    public Employee sbinj() {
        return new Employee("Sparsh", "Unhelpful Therapist", "Noot interested", "Roy.jpg");
    }

    public Employee aPhan() {
        return new Employee("Andy", "Pro Crastinator", "Trying again...", "aphan.jpg");
    }

    public Employee vanQuach() {
        return new Employee("Van", "CSE Student", "I want to have an internship", "bubbles.jpg");
    }

    public Employee kchenh() {
        return new Employee("Kai", "Head Bozo", "King of clowns", "clown.jpeg");
    }

    public Employee chien() {
        return new Employee("Chien", "Janiter", "I need a raise :( ", "Chien.jpg");
    }

    public Employee laniDang() {
        return new Employee("Lani", "worker", "trying my best", "Lani.jpg");    }

    public Employee brendenPage() {
        return new Employee("Brenden", "Professional toilet drinker", "If you need your toilet drunk hit me up", "toilet.jpg");
    }

    public Employee shaoqiWang() {
        return new Employee("Shaoqi", "Shaoqi loves cats.", "A traveling musician", "shaoqi.jpg");
    }

    public Employee jaydev() {
        return new Employee("Jaydev", "Kathakaar", "A traveling musician", "Jaydev.jpg");
    }

    public Employee aydan() {
        return new Employee("Aydan", "Director of Security", "alen dvdcaeltop ant endkdlw aviglgenal", "aydan.jpg");
    }

    public Employee klee33() {
        return new Employee("Kenneth", "God", "I am God in the human form", "thegod.jpg");
    }

    public Employee bzhang() {
        return new Employee("Ben Zhang", "Chief Photographer", "Smile!!", "bzhang.jpg");
    }

    public Employee detlefKnauss() {
        return new Employee("Detlef Knauss", "Lead canine manager at FAANG", "My FAANGs", "Detlef2.jpg");
    }

    public Employee chrisC() {
        return new Employee("Chris Choi", "Water Cooler Sommelier", "I know my water coolers", "Chris_Choi.jpg");
    }

    public Employee georgeMa() {
        return new Employee("George Ma","Chief of nothing", "Magic!!!", "zma9977.jpg");
    }

    public Employee colePurcell() {
        return new Employee("Cole Purcell", "Senior Meme Provider", "I have yet to find a picture that describes me better than this one.", "ColePurcell.PNG");
    }

    public Employee anotherJack() {
        return new Employee("Jack", "COO", "Dibs!", "fantasy_land.png");
    }

    public Employee arya() {
        return new Employee("Arya", "DJ", "Playing bangerzz is my ting!", "ARYA_GJ.jpg");
    }

    public Employee alexAlbert() {
        return new Employee("Alex Albert", "The One and Only", "You know what I do", "dog.jpeg");
    }

    public Employee ahmedMunir() {
        return new Employee("Ahmed", "4.0 Hunter", "I am doing 18 Credits sadface", "sadprogrammer.jpg");
    }

    public Employee andrewC() {
        return new Employee("Andrew", "Puppy Manager", "Managing over 3000 debug dogs since 1835", "andrewc.jpeg");
    }

    public Employee dmitriyShepelev() {
        return new Employee("Dmitriy", "Meme Manager", "Awarded Memesmith of the Year in 2020", "dshepelev.jpg");
    }

    public Employee marcusCh() {
        return new Employee("Marcus", "yesman", "yes", "marcusc2.jpg");
    }

    public Employee reinard() {
        return new Employee("Reinard", "Contributor", "I contribute a lot", "reinard.jpg");
    }

    public Employee hankt() {
        return new Employee("Hank", "Floor Scrubber", "Can I use something besides a toothbrush?", "hank.jpeg");
    }

    public Employee aleksJovcic() {
        return new Employee("Aleks", "VP of Vibes Coordination", "Just vibing", "ajovcic.jpg");
    }

    public Employee daniyal() {
        return new Employee("Daniyal", "Regional Manager DunderMifflin", "Worlds Best Boss, Dundee Winner", "daniyal.png");
    }

    public Employee stevePater() {
        return new Employee("Steve", "Master of the Custodial Arts", "Janitor if you want to be a dick about it.", "steve.jpg");
    }

    public Employee zhinuoL() {
        return new Employee("Zhinuo", "Employee", "Nice person", "zli.png");
    }

    public Employee philip() {
        return new Employee("Philip", "cool kid", "too school for cool", "philip.jpg");
    }

    public Employee vanessaRoss(){
        return new Employee("vanessa", "Animal Enthusiast", "Antisocial", "vanessa.jpg");
    }

    public Employee caroline() {
        return new Employee("Caroline", "Software Developer", "Best coder ever!", "CarolinePic.jpg");
    }

    public Employee vidhi(){
        return new Employee("Vidhi", "Professional Napper", "Top of the game", "vidhi.jpg");
    }

    public Employee jeremy(){
        return new Employee("Jeremy", "Software Developer at Google", "Wait I don't even work here", "Jeremy.jpg");
    }

    public Employee maxlc(){
        return new Employee("Max", "Just Some Guy", "I'm just chilling.", "max.jpg");
    }

    public Employee andreww() {
        return new Employee("Andrew", "Software Developer at Gooogsle", "I want to become CEO", "joebiden.png");
    }

    public Employee saagar(){
        return new Employee("Saagar", "Designated baker", "I bring joy to the workplace with sweet things", "saagar.jpg");
    }

    public Employee chris(){
        return new Employee("Chris", "A spectator", "All I do is watch.", "chris.jpg");
    }

    public Employee nithit(){
        return new Employee("Nithin", "Chief Vibes Officer", "Posititve Vibes Only on my watch", "nithit.jpg");
    }

    public Employee muru(){
        return new Employee("Muru", "A Amateur Intern", "Please give me the return offer!!!", "muru.jpg");
    }

    public Employee umair(){
        return new Employee("Umair", "assistant to the regional manager", "Lemme know for internships", "bob.jpg");
    }

    public Employee morel(){
        return new Employee("Morel", "Chief Excecutive Eater", "gnomgnomgnom", "morel.jpg");
    }

    public Employee jack() {
        return new Employee("Jack", "Resident Sleeper", "Zzzzzzzzz....", "sleep.jpg");
    }

    public Employee vinny() {
        return new Employee("Vinny", "probably the producer", "the chicken or the egg?", "vinny.jpg");
    }

    public Employee vishnu(){
        return new Employee("Vishnu", "Professional Coffee Fetcher for Senior Employees", "Give me a promotion please!.", "vishnu.jpg");
    }

    public Employee pyho() {
        return new Employee("Patrick", "CTO", "A very underqualified CTO", "pyho.jpeg");
    }

    public Employee luke() {
        return new Employee("Luke", "Gundam pilot", "I go and fight Zeon", "Amuro_Ray.jpg");
    }

    public Employee sierra() {
        return new Employee("Sierra", "Creator", "Product designer passionate about social good and advocacy", "sierra_selfie.jpg");
    }

    public Employee yingfc() {
        return new Employee("yingfc", "Keyboard manager", "I type to fight", "yingfan.jpg");
    }

    public Employee iulia() {
        return new Employee("Iulia", "Janitor", "Very organized", "iulia.jpg");
    }

    public Employee giselle() {
        return new Employee("Giselle", "Software Developer", "I like to watch", "giselle.jpg");
    }

    public Employee soren() {
        return new Employee("Soren", "Professional Slacker", "Nobody's kicked me out yet", "Soren Dahl.jpg");
    }

    public Employee mychal() {
        return new Employee("Michael", "Snacker", "Yum", "DSC_0562_3 (1).jpg");
    }

    public Employee thevina() {
        return new Employee("Thevina", "Assistant", "Team Leader", "profilepic.jpg");
    }

    public Employee jacobButNotAlreadyDeclared() {
        return new Employee("Jacob", "Janitor", "Here to cleannnnn", "jacob_mckenney.jpg");
    }

    public Employee nardin() {
        return new Employee("Nardin", "Social Networker", "I increased our company's engaement by 100%","nardin.jpg");
    }

    public Employee maggie() {
        return new Employee("Maggie", "Professional Napper", "zzzzzzz...", "staffpic.png");
    }

    public Employee evan() {
        return new Employee("Evan", "tomato enthusiast", "I like tomatoes", "evanhao.jpg");
    }

    public Employee tony() {
        return new Employee("Tony", "Unknown Staff A", "No one remembers me", "mimikyu.jpg");
    }

    public Employee assaf() {
        return new Employee("Assaf", "#1 emplyee of the decade", "a tab is not 3 spaces", "assafv.jpeg");
    }

    public Employee matthew() {
        return new Employee("Matthew", "grunt", "I just work", "matthew.PNG");
    }

    public Employee camilyo() {
        return new Employee("Camila", "Boss lady", "funny", "camilyo-me.jpeg");
    }

    public Employee benjamin() {
        return new Employee("Benjamin", "cs and shef double majored", "I DO COOK but...", "benjamin.jpg");
    }

    public Employee changliu() {
        return new Employee("Chang Liu", "Software Development Engineer", "Try to fight with bugs", "changliu.png");
    }

    public Employee ryan() {
        return new Employee("Ryan", "potato enthusiast", "I love potatoes", "Husky.jpeg");
    }

    public Employee mike() {
        return new Employee("Mike", "Adventure Completionist", "Destroyer of Fog of War", "mike.jpg");
    }

    public Employee alicia() {
        return new Employee("Alicia", "Chief Evangelism Officer", "Abbreviate it however you want", "Alicia.png");
    }

    public Employee james() {
        return new Employee("James", "Senior Upper Position Executive Remote Computer Engineering Officer", "Abbreviate it however you want", "James.png");
    }

    public Employee lwx() {
        return new Employee("lwx", "dagongren", "I like working", "lwx.jpg");
    }

    public Employee jiamae(){
        return new Employee("Jiamae", "gamer gorl", "i ain't never seen two pretty best friends", "jiamae.jpg");
    }

    public Employee camdenf(){
        return new Employee("Camden", "Ex Analyst", "I hate Navy ships", "camden-shepherd.jpg");
    }

    public Employee JacksonL(){
        return new Employee("Jackson", "Future SDE", "light_weight", "jkl.jpg");
    }

    public Employee tiphanie() {
        return new Employee("Tiphanie", "Future coffee shop owner", "Please carry", "tiphanieleung.jpg");
    }

    public Employee kaylahoang() {
        return new Employee("Kayla Hoang", "Space enthusiast", "I love musicals!", "kayla.jpg");
    }

    public Employee YaeK() {
        return new Employee("Yae", "cookie connoisseur", "Consantly in need of coffee", "staffpug.png");
    }

    public Employee jacobC() {
        return new Employee("Jacob", "Chief DoingThings Officer", "I do things... sometimes mutliple things", "jacobChr.jpg");
    }

    public Employee JohnR() {
        return new Employee("John", "the cat dude", "I make sure everyone has a cat", "john_bio.jpg");
    }

    public Employee YechenWang() {
        return new Employee("Mike", "Project Manager", "Organizing Team", "yechenW.png");
    }

    public Employee tpp() {
        return new Employee("Yetao", "keyboardist", "Keyboardist in band Venus", "tpp.jpg");
    }

    public Employee nur() {
        return new Employee("Nur", "new employee", "I'm new here", "nsdin.jpeg");
    }

    public Employee minh() {
        return new Employee("Minh", "Streamer", "It's just me", "hihi.jpg");
    }

    public Employee kwang() {
        return new Employee("Kevin", "Worker?" ,"Work hard play hard", "kwang.jpg");
    }

    public Employee justinyang(){
        return new Employee("Justin", "Employee of the century", "Be a Justin", "Justin_profile_pic.jpg");
    }

    public Employee bellarivera(){
        return new Employee("Bella", "intern", "i'm just happy to be here", "bellastaffpic.jpg");
    }

    public Employee Qingyuan() {
        return new Employee("Qingyuan", "keyboard artist", "paid time off", "Qingyuan.jpeg");
    }

    public Employee Gaurav(){
        return new Employee("Gaurav", "Proffesional TV Watcher", "I love myself","CroppedHeadshot.jpg");
    }

    public Employee Vania() {
        return new Employee("Vania", "orange seller", "Heyo", "vania.jpg");
    }

    public Employee Andreea() {
        return new Employee("Andreea", "Not a rower", "trying to eat healthy but I'm addicted to cheezits :(", "canoeist.jpg");
    }

    public Employee Zage() {
        return new Employee("Zage", "full time student", "I love drinking tea", "zage.png");
    }

    public Employee Rahul() {
        return new Employee("Rahul", "Artist", "I love ATLA a lot", "rahul.jpg");
    }

    public Employee pjrk() {
        return new Employee("Paul", "student", "matrices are really cool", "pjrk.jpg");
    }

    public Employee Chloe() {
        return new Employee("Chloe", "Phat dumb brain", "What a weirdo", "Chloe.jpg");
    }

    public Employee noah() {
        return new Employee("Noah", "Coffee Deliverer", "I'm an intern, I don't know anything", "noah.jpg");
    }

    public Employee Joan() {
        return new Employee("Joan", "student, mother", "Try it again!", "qkwo.jpg");
    }

    public Employee Dylan() {
        return new Employee("Dylan", "Dylan Enthusiast", "love yourself", "dylan_geva.jpg");
    }

    public Employee Matt() {
        return new Employee("Matt", "Student", "Is a learner", "Matthew-Johnson.jpg");
    }

    public Employee spongebobSquarepants() {
        return new Employee("Spongebob", "Fry cook", "I'm ready", "spongebob-squarepants.png");
    }

    public Employee Iman(){
        return new Employee("Iman", "Chicken Mutant", "When Chickens Fly", "iman.jpg");
    }

    public Employee Justin() {
        return new Employee("Justin", "Justin", "Justin", "justin.png");
    }

    public Employee Aiden(){
        return new Employee("Aiden", "Certified Something-or-Another", "Bold of you to presume I'm human.", "aidena_iridbubble.jpg");
    }

    public Employee davidroy() {
        return new Employee("David Roy", "Software Developer @ Thriller Solutions", "Visit thrillersolutions.com!", "davidroy.jpg");
    }

    public Employee anirudh(){
        return new Employee("Anirudh", "Booler", "I thought FAANG was a vampire company. Somehow I passed the interview...", "anirudh.jpg");
    }

    public Employee xinjieH() {
        return new Employee("Xinjie Huang", "Student", "I sorta know front-end", "xinjie_huang.jpg");
    }

    public Employee xiaoning() {
        return new Employee("xiaoning bu", "Data scientist", "I use tensorflow a lot", "xiaoning.jpg");
    }

    public Employee AlexWang(){
        return new Employee("Alex Wang", "Sports fan", "Avid golfer", "Alex.jpeg");
    }

    public Employee varun() {
        return new Employee("Varun", "Hype Man", "Got hired somehow idk.", "varun.jpg");
    }

    public Employee zhengC() {
        return new Employee("Zheng Chen", "Dish Washer", "Balabalabala", "Zheng.jpeg");
    }

    public Employee melissaM() {
        return new Employee("Melissa", "intern", "I eat lettuce and carrots", "Bell.jpeg");
    }

    public Employee hannahyk() {
        return new Employee("Hannah", "Coffee enthusiast", "Also a fan of tea", "hannah.jpg");
    }

    public Employee sulaimanM(){
        return new Employee("sulaiman", "Bayyan enthusiast", "I like talking ", "democracy.png");
    }

    public Employee Kevin(){
        return new Employee("Kevin", "Professional Napper", "i can shleep", "kevin.png");
    }

    public Employee mshang() {
        return new Employee("Matthew", "Student", "Hi", "sunglasses.png");
    }

    public Employee kennethMa() {
        return new Employee("Kenneth", "Student", "Heyo", "kennethma.jpg");
    }

    public Employee PatrickM() {
        return new Employee("Patrick", "I messed this up like twice", "Interest changer", "Patrick.jpg");
    }

    public Employee FrancescaW() {
        return new Employee("Francesca", "My git push is not working properly", "So I have 2 urls on Gradescope", "FrancescaW.jpg");
    }

    public Employee AllisonGu() {
        return new Employee("Allison", "Student", "Why is this assignment taking me so long lol", "Allison.png");
    }

    public Employee nakiar() {
        return new Employee("Nakia", "Student and Part-timer ", "I was born in Tillamook, they're known for their dairy products", "cowtown.jpg");
    }

    public Employee hasan() {
        return new Employee("Hasan", "Hasan", "Hasan", "hasan.jpg");
    }

    public Employee TuanT() {
        return new Employee("TuanT", "I do CS stuff", "I suck at CS stuff", "Tuant.jpg");
    }

    public Employee connor(){
        return new Employee("Connor", "Russian Oligarch", "Since it's truck month why don't you head on down to your local dodge dealer and pick up a Dodge Ram 1500; best in class towing with the capability to tow up to 12,000lbs of steel beams, with a 5 star safety rating and winner of 4 JD power and associates awards and 2019s motor trend truck of the year", "acatar.png");
    }

    public Employee jacob(){
        return new Employee("jacob", "Broke College Student", "I'm broke and in college suffering", "Jacob.JPG");
    }

    public Employee WilliamT() {
        return new Employee("William", "code monkey", "Will code for food", "william.png");
    }

    public Employee Erc() {
        return new Employee("Eric", "Imposter Syndrome Specialist", "Don't ask me anything I probably know less than anyone else you could ask", "erc.jpg");
    }

    public Employee tylerN() {
        return new Employee("Tyler", "Soy Sauce Connoisseur", "Mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm", "tylerN.png");
    }

    public Employee mitty() {
        return new Employee("Mitchell", "Communications Assistant", "Don't try to contact me I won't respond", "mitchell.jpg");
    }

    public Employee anson() {
        return new Employee("Anson","Janitorial and Hygiene Technician","I'm an imposter, I'm actaully the CEO.","anson.jpg");
    }

    public Employee vishal() {
        return new Employee("Vishal", "Faang company enthusiast", "I may not be the strongest, or the wisest, or the smartest", "dedede.png");
    }

    public Employee alliePfleger() {
        return new Employee("Allie", "Resident Knitter", "Someone needs to pet all this soft and fluffy yarn.", "alliePfleger.jpg");
    }

    public Employee rishabh() {
        return new Employee("Rishabh", "unpaid intern", "i make good coffee", "rishabh.jpg");
    }

    public Employee Jun() {
        return new Employee("JUn", "Human?", "Do people even read this?", "Jun.jpg");
    }

    public Employee Ghaith() {
        return new Employee("Ghaith", "sleeping expert", "currently sleeping", "Ghaith.jpeg");
    }

    public Employee Morgan() {
        return new Employee("Morgan", "cat observer", "I have cats", "Morgan.JPG");
    }

    public Employee NickS() {
        return new Employee("NickS", "mafia boss", "coding", "NickS.jpg");
    }

    public Employee Andrea() {
        return new Employee("Andrea", "Sealiest student", "Floopin' around", "images.jpg");
    }

    public Employee AnthonyC() {
        return new Employee("Anthony C", "Sushi enthusiast", "How old were you when you were 8?", "anthonyC.jpg");
    }

    public Employee JacobZ() {
        return new Employee("Jacob", "Struggling Student", "Someone plz give me an internship", "jacobcz.jpg");

    }

    public Employee Robert() {
        return new Employee("Robert", "Chief Swag Officer", "Hmm...", "hughcarthy.jpg");
    }

    public Employee PeterC(){
        return new Employee("Peter", "LOVEGIT", ":)", "chia_hao.jpg");
    }

    public Employee Sunny() {
        return new Employee("Sunny", "happy student", "I am eating chocolate cake now, so I am happy.", "sunny.png");
    }

    public Employee aaronTou() {
        return new Employee("Aaron", "Stanford undergrad", "yezzzzzir", "Decorated Aaron.png");
    }

    public Employee Peyton() {
        return new Employee("Peyton", "Suffering Student", "My picture represents the person I want to be", "SLOTH.jpg");
    }

    public Employee Tuan() {
        return new Employee("Tuan!", "The one", "There's no one above, up above", "daniel_caesar.jpg");
    }

    public Employee Ryan() {
        return new Employee("Ryan", "Investamigaterater", "BIG UPS to whoever gives me an internship offer", "gosling.jpg");
    }

    public Employee Jeyamerun() {
        return new Employee("Jeyamerun", "Built Different", "Add the snap: merun_fast", "Jeyamerun.jpeg");
    }

    public Employee Asriel() {
        return new Employee("Asriel","Built the same","Follow the gram: @Riel._.Ash","Asreil.jpg");
    }

    public Employee Aadi() {
        return new Employee("Aadi Jain", "CSE:Omae Wa Mou Shindeiru, Me:NANI", "Chronic Procrastinator", "AadiJain.jpg");
    }

    public Employee Riya() {
        return new Employee("Riya", "Allen School Student", "dedicated", "Riya.jpg");
    }

    public Employee AlexHughes() {
        return new Employee("Alex Hughes", "Yogurt", "I love yogurt", "alex.jpg");
    }

    public Employee Thai() {
        return new Employee("Thai Hoang", "Another one", "Hello", "thai_hoang.jpeg");
    }

    public Employee Muskan(){
        return new Employee("Muskan Bawa", "The cool kid", "kind", "image_upload.jpeg");
    }
}
