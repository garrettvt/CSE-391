public class Printer {
    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            System.out.println("faang is the best company ever!!");
        }
    }
}
