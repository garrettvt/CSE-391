public class YetAnotherPrinter {
    public static void main(String[] args) {
        String i = "I ";
        String l = "love ";
        String f = "faang faang";
        System.out.println(i + l + f);
    }
}
